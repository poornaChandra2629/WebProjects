package com.poorna.webapplication.springboot.poornaWebapplicationSpringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PoornaWebapplicationSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
